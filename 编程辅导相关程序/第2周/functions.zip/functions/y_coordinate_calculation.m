function y_output = y_coordinate_calculation(x)
%%This function takes a vector of coordinates x as input and outputs the corresponding y
%coordinates in a vector.

y_output = sin(4*x).^2*6;


end

