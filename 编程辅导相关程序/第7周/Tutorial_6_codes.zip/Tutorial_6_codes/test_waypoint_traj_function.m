% this code uses the function WaypointTraj to build a waypoint trajectory
% basically it does exactly the same as the code trajectory_interpolation.m
% but using a function
clear all
close all

Tf = 3;                             % [s] total duration of trajectory
N=20;                               % []  number of steps in each path
% specify the HTMs in each way-point
T0 = RpToTrans(eye(3), [0 1 1]');
T1 = RpToTrans(rotx(pi), [0 2 1.3]');
T2 = RpToTrans(rotx(pi)*roty(pi/2), [0.5 2 0.8]');
T3 = RpToTrans(rotx(pi)*roty(pi/2)*rotz(pi/5), [0.5 1 0.2]');
figure(4)
trplot(T0, 'length', 0.2)
hold on
trplot(T1, 'length', 0.2)
trplot(T2, 'length', 0.2)
trplot(T3, 'length', 0.2)
% create array with all HTMs waypoints
Tlist = zeros(4,4,4);
Tlist(:,:,1) = T0 ;
Tlist(:,:,2) = T1 ;
Tlist(:,:,3) = T2 ;
Tlist(:,:,4) = T3 ;

[Tsd] = WaypointTraj(Tf, N, Tlist)

% plotting
figure(1)
view(62,34)
x0=100;     % location of figure in the screen
y0=200;     % location of figure in the screen
width=400;  % width of figure
height=300; % height of figure
set(gcf,'position',[x0,y0,width,height])
Np = max(size(Tlist(1,1,:)))-1;
t = linspace(0,Tf,N*Np);
for i=1:N*Np
    Tsd1 = Tsd(:,:,i);
    x(i) = (Tsd(1,4,i));
    y(i) = (Tsd(2,4,i));
    z(i) = (Tsd(3,4,i));
    if i>1
       dotx(i) = (x(i)-x(i-1))/(Tf/Np*N); 
       doty(i) = (y(i)-y(i-1))/(Tf/Np*N); 
       dotz(i) = (z(i)-z(i-1))/(Tf/Np*N); 
    end
    trplot(Tsd1, 'length', 0.1)
    hold on
end

figure(2)
x0=400;     % location of figure in the screen
y0=200;     % location of figure in the screen
width=400;  % width of figure
height=300; % height of figure
set(gcf,'position',[x0,y0,width,height])
plot(t,x)
hold on
plot(t,y,'r')
plot(t,z,'k')
legend('$x$', '$y$', '$z$','interpreter', 'latex')
xlabel('time [$s$]','interpreter', 'latex')
ylabel('position [$m$]','interpreter', 'latex')
title('way-point trajectory with cubic time scaling','interpreter', 'latex')

figure(3)
x0=800;     % location of figure in the screen
y0=200;     % location of figure in the screen
width=400;  % width of figure
height=300; % height of figure
set(gcf,'position',[x0,y0,width,height])
plot(t,dotx)
hold on
plot(t,doty,'r')
plot(t,dotz,'k')
legend('$\dot x$', '$\dot y$', '$\dot z$','interpreter', 'latex')
xlabel('time [$s$]','interpreter', 'latex')
ylabel('velocity [$m/s$]','interpreter', 'latex')
title('way-point trajectory with cubic time scaling','interpreter', 'latex')
