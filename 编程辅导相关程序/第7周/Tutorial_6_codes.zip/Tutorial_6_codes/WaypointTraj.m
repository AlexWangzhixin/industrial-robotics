function [Tsd] = WaypointTraj(Tf, N, Tlist)
%this function creates a waypoint trajectory taking as arguments:
%   Tf    = the total duration of the trajectory
%   N     = the number of HTMs inside each sub-path of the trajectory
%   Tlist = a threedimentional matrix containing the waypoints expressed as HTMs 
%   this is how Tlist should be defined, for example, in the case of 4 waypoints:
%   Tlist(:,:,1) = T0 ;
%   Tlist(:,:,2) = T1 ;
%   Tlist(:,:,3) = T2 ;
%   Tlist(:,:,4) = T3 ;

Np = max(size(Tlist(1,1,:)))-1;
Tsd = zeros(4,4,N*Np);

for i=1:Np
traj = CartesianTrajectory(Tlist(:,:,i), Tlist(:,:,i+1), Tf/Np, N, 3); 
    for h=1:N
        m = i*N-N+h;
        Tsd(:,:,m) = cell2mat(traj(h));
    end
end
return
end